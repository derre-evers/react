export const beverages = [
    { image: require('../images/beer.png'), name: "beer" }, 
    { image: require('../images/chocolate.png'), name: "chocolate" }, 
    { image: require('../images/cider.png'), name: "cider" }, 
    { image: require('../images/cocktail.png'), name: "cocktail" }, 
    { image: require('../images/coffee.png'), name: "coffee" }, 
    { image: require('../images/coca.png'), name: "coca" }, 
    { image: require('../images/lemonade.png'), name: "lemonade" }, 
    { image: require('../images/tea.png'), name: "tea" }, 
    { image: require('../images/water.png'), name: "water" }, 
    { image: require('../images/whiskey.png'), name: "whiskey" }, 
    { image: require('../images/wine.png'), name: "wine" }, 
];