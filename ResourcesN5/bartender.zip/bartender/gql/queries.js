import { gql } from "@apollo/client";

export const GET_CATEGORIES = gql`
query GetCategories{
    categories (order_by:{name: asc}){
        id
        name
    }
}`;

export const GET_FILTERED_BEVERAGES = gql`
query GetFilteredBeverages($category:Int!){
    beverages (where: {category_id : {_eq: $category}}){
        id
        name
        price
        plus18
              
    }
}`
