import { Image, View, Text, StyleSheet } from 'react-native';

import { beverages } from '../images/beverages';

export default function OrderItem({ item }) {
  let name = item.drink.name
  const url =beverages[beverages.findIndex((item) => item.name === name)].image
  let turf = ''
  for(let i=1;i<=item.count;i++){
    turf+= 'l'
  }
  return (
    <View style={styles.container}>
      <Image style={styles.image} source={url} />
      <Text style={styles.name} >{name} {turf}</Text>      
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    padding: 8,
  },
  column: {
    justifyContent: 'center',
  },
  name: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  image: {
    width: 50,
    height: 50,
    marginRight: 5
  }
});