import { FlatList, View, StyleSheet, Text } from 'react-native';
import {useEffect} from 'react';
import Fetching from './layout/message_fetching';
import Error from './layout/message_error';
import Separator from './layout/seperator';
import { useLazyQuery } from '@apollo/client';
import BeverageItem from './beverage_item';
import { useRecoilState } from 'recoil';
import { categoryState } from '../store';
import { GET_FILTERED_BEVERAGES } from '../gql/queries';

export default function ListBeverages() {
  const [category, setCategory] = useRecoilState(categoryState);
  const [loadData,{data, loading, error}] = useLazyQuery(GET_FILTERED_BEVERAGES, {variables: {category: category}});
  useEffect(()=>{
    console.log(category)
    if(category !==0){      
      loadData()
      console.log(data)
    }
   
  }, [category])
  if (loading) return <Fetching />
  if (error) return <Error error={error} />
  return (
    <View style={styles.container}>
      {category !== 0 &&
      <FlatList
        data={data.beverages}
        renderItem={({ item }) => <BeverageItem beverage={item}/>}
        keyExtractor={(item, index) => index}
        ItemSeparatorComponent={Separator}
  />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    marginTop: 20
  },
});