import { FlatList, View, StyleSheet } from 'react-native';

import Separator from './layout/seperator';
import OrderItem from './order_item';

export default function ListOrder({order}) {
  console.log('ord',order);
  return (
    <View style={styles.container}>
      <FlatList
        data={order}
        renderItem={({ item }) => <OrderItem item={item}/>}
        keyExtractor={(item, index) => index}
        ItemSeparatorComponent={Separator}
  />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'center',
    padding: 8,
  }
});